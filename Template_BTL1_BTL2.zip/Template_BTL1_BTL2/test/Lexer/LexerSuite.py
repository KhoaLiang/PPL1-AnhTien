"""
 * Initial code for Assignment 1, 2
 * Programming Language Principles
 * Author: Võ Tiến
 * Link FB : https://www.facebook.com/Shiba.Vo.Tien
 * Link Group : https://www.facebook.com/groups/khmt.ktmt.cse.bku
 * Date: 07.01.2025
"""
import sys
import os
import unittest
import inspect

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from TestUtils import TestLexer

class LexerSuite(unittest.TestCase):
      
    def test_001(self):
        """test simple"""
        self.assertTrue(TestLexer.test("Votien10cham","Votien10cham,<EOF>", inspect.stack()[0].function))

    def test_002(self):
        """test complex"""
        self.assertTrue(TestLexer.test("int Votien = 10 + 10;","int,Votien,=,10,+,10,;,<EOF>", inspect.stack()[0].function))
        
    def test_003(self):
        """test complex error"""
        self.assertTrue(TestLexer.test1(".","Error Token .", inspect.stack()[0].function))
        
    def test_004(self):
        """test complex fail1"""
        self.assertTrue(TestLexer.test("int","in,<EOF>", inspect.stack()[0].function))
        
    def test_005(self):
        """test complex fail2"""
        self.assertTrue(TestLexer.test("int","int", inspect.stack()[0].function))
        
    